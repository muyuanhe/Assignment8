### Problem 1
import random
import numpy as np
import matplotlib.pyplot as plt

T = 10,
num = int(1e5)
arr1 = np.linspace(1, T, num)
arr2 = np.zeros(num)
for i in np.arange(num):
    arr2[i] = 1/arr1[i]
arr1 = np.ndarray.tolist(arr1)
arr2 = np.ndarray.tolist(arr2)
ran = random.choices(arr1, weights = arr2, k = num)
ran2 = []
for j in ran:
    ran2.append(j[0])
print(ran2)

plt.hist(ran2, density = True, bins = 100)
plt.ylabel('Probability')
plt.xlabel('Data')
plt.show()

