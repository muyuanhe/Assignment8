### Problem 2
# part c

k1 = 0.1
N = 2
sim_num = 1000
r1 = []
r2 = []
r1[0] = [-0.5, 0, 0]
r2[0] = [0.5, 0, 0]
#ridot[0] = 0


def vint(x):
    v = (1*(x-1)**2)/2
    return v

def new_position(x,v,dt):
    x_new = x + v * dt / 2
    return x_new

def new_velocity(v,F,dt):
    v_new = v + F * dt / 2
    return v_new





sim_list = []
for i in np.arange(sim_num):
    sim_list.append()